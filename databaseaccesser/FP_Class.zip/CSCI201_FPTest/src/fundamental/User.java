package fundamental;


/* Basic structure of a User instance.
 * 
 * 
 * 
 * 
 */

import java.util.Vector;

public class User {
	//Basic Data Member
	private int userID;
	private String email;
	private String password;
	private String name;
	private Vector<Integer> books;
	
	private String picture; //toChange
	private String lastKnownPosition; //toChange
	
	
	//Constructor, used upon user registration
	public User(String email, String password, String name, Vector<Integer> books, String picture, String lastKnownPosition) {
		this.email=email;
		this.password=password;
		this.name = name;
		this.books = books;
		this.picture = picture;
		this.lastKnownPosition = lastKnownPosition;
	}
	
	public boolean editName(String name) {
		if (name.length() > 20) {
			return false;
		}
		
		this.name = name;
		int userID = this.userID;
		databaseAccessor.updateUserName(userID, name);
		
		return true;
	}
	
	public boolean editPicture(String photoBlob) {
		
		
		this.picture = photoBlob;
		int userID = this.userID;
		databaseAccessor.updateUserPicture(userID, photoBlob);
		
		return true;
	}
	
	public boolean addBook(String title, String author, String photoBlob, int rating) {
		int ownerID = this.userID;
		String position = this.lastKnownPosition;
		
		int bookID = databaseAccessor.addBook(ownerID, title, author, photoBlob, rating);
		//TODO add bookID to the User DataBase
		
		
		return true;
	}
	
	public boolean deleteBook(int index) {
		int bookID = books.get(index);
		
		databaseAccessor.deleteBook(bookID);
		
		return true;
	}
	
	public boolean updatePosition(String position) {
		this.lastKnownPosition = position;
		int userID = this.userID;
		
		databaseAccessor.updateUserPosition(userID, position);
	}

}
