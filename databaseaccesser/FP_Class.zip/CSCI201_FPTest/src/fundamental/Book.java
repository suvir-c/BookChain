package fundamental;

/* Basic structure of a book instance.
 * 
 * 
 * 
 * 
 */


public class Book {
	private int bookID;
	private int ownerID;
	private String author;
	private int rating;
	private String title;
	
	private String position;
	private String picture;
	

}
