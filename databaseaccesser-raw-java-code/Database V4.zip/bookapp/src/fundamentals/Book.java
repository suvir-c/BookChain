package fundamentals;

public class Book {
    private int bookID;
    public int getBookID() {
		return bookID;
	}

	public String getTitle() {
		return title;
	}
	
	public void setLatitude(double latitude) {
		this.owner_latitude = latitude;
	}
	
	public void setLongtitude(double longitude) {
		this.owner_longitude = longitude;
	}
	
	private int ownerID;
	private double owner_latitude; //New
	private double owner_longitude; //New
    private String author;
    private int rating;
    private String title;
    private String picture;
    
    public Book(int bookID, int ownerID, String author, int rating, String title, String picture, Double latitude, Double longitude) {
    	this.bookID = bookID;
    	this.ownerID = ownerID;
    	this.author = author;
    	this.rating = rating;
    	this.title = title;
    	this.picture = picture;
    	this.owner_latitude = latitude;
    	this.owner_longitude = longitude;
    }

}
